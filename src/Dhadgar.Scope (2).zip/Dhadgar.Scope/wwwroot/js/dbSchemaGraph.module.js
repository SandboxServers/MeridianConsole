/* Meridian Console - DB Schema Graph (Cytoscape)
   - Services become "schema clusters" (compound nodes).
   - Items (tables/views/functions/enums) are nodes.
   - Relationships are edges.
*/

const cytoscapeRef = (typeof window !== "undefined" ? window.cytoscape : globalThis.cytoscape);
if (!cytoscapeRef) {
  console.warn("cytoscape not found on window. Ensure cytoscape.min.js is loaded in index.html.");
}

const instances = new Map();

function kindClass(kind) {
  const k = (kind || "table").toLowerCase();
  if (k === "table") return "k-table";
  if (k === "view") return "k-view";
  if (k === "function") return "k-fn";
  if (k === "enum" || k === "type") return "k-type";
  return "k-other";
}

function buildPositions(catalog) {
  // Place schemas around a ring, and items in a mini-grid per schema.
  const services = catalog.services || [];
  const centers = new Map();

  const radiusX = 520;
  const radiusY = 320;
  const n = Math.max(1, services.length);

  services.forEach((s, i) => {
    const a = (Math.PI * 2 * i) / n;
    centers.set(s.key, { x: Math.cos(a) * radiusX, y: Math.sin(a) * radiusY });
  });

  const positions = new Map(); // itemId -> {x,y}
  services.forEach((s) => {
    const c = centers.get(s.key) || { x: 0, y: 0 };
    const buckets = { table: [], view: [], function: [], enum: [], type: [], other: [] };

    for (const it of (s.items || [])) {
      const k = (it.kind || "table").toLowerCase();
      if (buckets[k]) buckets[k].push(it);
      else buckets.other.push(it);
    }

    const clusterOffsets = {
      table: { x: 0, y: 0 },
      view: { x: 200, y: -120 },
      function: { x: -220, y: 120 },
      enum: { x: -220, y: -140 },
      type: { x: 200, y: 120 },
      other: { x: 0, y: 220 },
    };

    for (const [k, arr] of Object.entries(buckets)) {
      const off = clusterOffsets[k] || { x: 0, y: 0 };
      const cols = 3;
      const spacingX = 170;
      const spacingY = 70;

      arr.forEach((it, idx) => {
        const row = Math.floor(idx / cols);
        const col = idx % cols;
        const x = c.x + off.x + (col - 1) * spacingX;
        const y = c.y + off.y + row * spacingY;
        positions.set(it.id, { x, y });
      });
    }
  });

  return { centers, positions };
}

function makeElements(catalog) {
  const els = [];

  const { centers, positions } = buildPositions(catalog);

  for (const s of (catalog.services || [])) {
    els.push({
      data: { id: `svc_${s.key}`, key: s.key, label: `${s.name} (${s.schema})`, kind: "schema" },
      classes: "schema",
      selectable: false,
      grabbable: false,
    });

    for (const it of (s.items || [])) {
      const pos = positions.get(it.id) || { x: 0, y: 0 };
      els.push({
        data: {
          id: it.id,
          label: it.id,
          kind: it.kind || "table",
          serviceKey: s.key,
          schema: s.schema
        },
        position: pos,
        parent: `svc_${s.key}`,
        classes: `${kindClass(it.kind)} item`
      });
    }

    for (const r of (s.relationships || [])) {
      const id = `rel_${r.from}__${r.to}`;
      els.push({
        data: { id, source: r.from, target: r.to, label: r.label || "FK" },
        classes: "rel"
      });
    }
  }

  return els;
}

function createCy(hostEl, elements, options) {
  const cy = cytoscapeRef({
    container: hostEl,
    layout: { name: "preset" },
    elements,
    boxSelectionEnabled: false,
    wheelSensitivity: 0.14,
    userZoomingEnabled: true,
    userPanningEnabled: true,
    minZoom: options?.mode === "embed" ? 0.2 : 0.1,
    maxZoom: 2.3,
    style: [
      {
        selector: ".schema",
        style: {
          "shape": "roundrectangle",
          "background-color": "rgba(255,255,255,0.03)",
          "border-color": "rgba(255,255,255,0.15)",
          "border-width": 1,
          "label": "data(label)",
          "text-valign": "top",
          "text-halign": "center",
          "font-size": 11,
          "color": "rgba(255,255,255,0.55)",
          "text-margin-y": 8,
          "padding": 18
        }
      },
      {
        selector: ".item",
        style: {
          "label": "data(label)",
          "font-size": 11,
          "color": "rgba(255,255,255,0.88)",
          "text-wrap": "wrap",
          "text-max-width": 220,
          "text-valign": "center",
          "text-halign": "center",
          "shape": "roundrectangle",
          "background-color": "rgba(99,102,241,0.18)",
          "border-color": "rgba(99,102,241,0.65)",
          "border-width": 1.5,
          "padding": 10,
          "width": "label",
          "height": "label"
        }
      },
      { selector: ".k-table", style: { "background-color": "rgba(99,102,241,0.18)", "border-color": "rgba(99,102,241,0.75)" } },
      { selector: ".k-view", style: { "background-color": "rgba(14,165,233,0.16)", "border-color": "rgba(14,165,233,0.75)" } },
      { selector: ".k-fn", style: { "background-color": "rgba(245,158,11,0.16)", "border-color": "rgba(245,158,11,0.75)" } },
      { selector: ".k-type", style: { "background-color": "rgba(168,85,247,0.16)", "border-color": "rgba(168,85,247,0.75)", "shape": "ellipse" } },

      {
        selector: "edge",
        style: {
          "curve-style": "bezier",
          "width": 2,
          "line-color": "rgba(255,255,255,0.22)",
          "target-arrow-shape": "triangle",
          "target-arrow-color": "rgba(255,255,255,0.22)",
          "label": "data(label)",
          "font-size": 9,
          "text-rotation": "autorotate",
          "text-margin-y": -8,
          "color": "rgba(255,255,255,0.55)"
        }
      },
      { selector: ".rel", style: { "line-style": "solid", "width": 2.4 } },
      { selector: ".dim", style: { "opacity": 0.14 } },
      { selector: ".selected", style: { "border-width": 3, "border-color": "rgba(255,255,255,0.85)" } }
    ]
  });

  return cy;
}

function restoreBasePositions(inst) {
  if (!inst.basePositions) return;
  inst.cy.nodes().forEach(n => {
    if (n.isParent()) return;
    const p = inst.basePositions.get(n.id());
    if (p) n.position({ x: p.x, y: p.y });
  });
}

function applyExplode(inst) {
  const t = Math.max(0, Math.min(1, (inst.explode ?? 0) / 100));
  const factor = 2.0 * t;

  // base positions are already around a ring. Explode pushes further out.
  inst.cy.nodes().forEach(n => {
    if (n.isParent()) return;
    const pos = n.position();
    // push in direction from origin
    const dx = pos.x * factor * 0.35;
    const dy = pos.y * factor * 0.35;
    n.position({ x: pos.x + dx, y: pos.y + dy });
  });
}

function clearDim(cy) {
  cy.elements().removeClass("dim");
}

function dimAllBut(cy, focusEls) {
  cy.elements().addClass("dim");
  focusEls.removeClass("dim");
}

function searchInternal(inst, q) {
  const query = (q || "").trim().toLowerCase();
  inst.query = query;

  if (!query) {
    clearDim(inst.cy);
    applyServiceFilter(inst);
    return;
  }

  const matches = inst.cy.nodes().filter(n => {
    if (n.isParent()) return false;
    const id = (n.id() || "").toLowerCase();
    return id.includes(query);
  });

  if (matches.length === 0) {
    inst.cy.elements().addClass("dim");
    return;
  }

  const focus = matches.union(matches.neighborhood()).union(matches.connectedEdges());
  dimAllBut(inst.cy, focus);
}

function applyServiceFilter(inst) {
  const key = (inst.serviceKey || "").trim();
  if (!key) {
    inst.cy.nodes().style("display", "element");
    inst.cy.edges().style("display", "element");
    // keep schema nodes visible too
    return;
  }

  inst.cy.nodes().forEach(n => {
    if (n.isParent()) {
      n.style("display", n.data("key") === key ? "element" : "none");
      return;
    }
    n.style("display", n.data("serviceKey") === key ? "element" : "none");
  });

  // edges only when both ends are visible
  inst.cy.edges().forEach(e => {
    const s = e.source();
    const t = e.target();
    const visible = s.style("display") !== "none" && t.style("display") !== "none";
    e.style("display", visible ? "element" : "none");
  });
}

function clearSelectionInternal(inst) {
  inst.cy.nodes().removeClass("selected");
  inst.selected = null;
}

// Public API

export function init(instanceId, hostEl, catalog, options) {
  if (!hostEl) return;
  hostEl.innerHTML = "";

  const elements = makeElements(catalog);
  const cy = createCy(hostEl, elements, options);

  const basePositions = new Map();
  cy.nodes().forEach(n => { if (!n.isParent()) basePositions.set(n.id(), { x: n.position('x'), y: n.position('y') }); });

  const inst = {
    cy,
    basePositions,

    hostEl,
    catalog,
    explode: 0,
    query: "",
    serviceKey: "",
    selected: null,
    selectable: options?.selectable === true,
    dotnet: options?.dotnet || null
  };

  instances.set(instanceId, inst);

  if (inst.selectable) {
    cy.on("tap", "node", async (evt) => {
      const n = evt.target;
      if (!n || n.isParent()) return;
      clearSelectionInternal(inst);
      n.addClass("selected");
      inst.selected = n.id();
      if (inst.dotnet && typeof inst.dotnet.invokeMethodAsync === "function") {
        try { await inst.dotnet.invokeMethodAsync("OnItemSelected", n.id()); } catch {}
      }
    });
  }

  applyServiceFilter(inst);
}

export function setExplode(instanceId, value) {
  const inst = instances.get(instanceId);
  if (!inst) return;
  inst.explode = Number(value || 0);
  restoreBasePositions(inst);
  applyServiceFilter(inst);
  if (inst.query) searchInternal(inst, inst.query);
  applyExplode(inst);
  inst.cy.resize();
}

export function setServiceFilter(instanceId, serviceKey) {
  const inst = instances.get(instanceId);
  if (!inst) return;
  inst.serviceKey = serviceKey || "";
  applyServiceFilter(inst);
  if (inst.query) searchInternal(inst, inst.query);
}

export function search(instanceId, q) {
  const inst = instances.get(instanceId);
  if (!inst) return;
  searchInternal(inst, q);
}

export function fit(instanceId) {
  const inst = instances.get(instanceId);
  if (!inst) return;
  inst.cy.fit(inst.cy.elements(":visible"), 80);
}

export function reset(instanceId) {
  const inst = instances.get(instanceId);
  if (!inst) return;
  clearSelectionInternal(inst);
  inst.query = "";
  inst.serviceKey = "";
  inst.explode = 0;
  restoreBasePositions(inst);
  applyServiceFilter(inst);
  clearDim(inst.cy);
  inst.cy.fit(inst.cy.elements(":visible"), 80);
}

export function clearSelection(instanceId) {
  const inst = instances.get(instanceId);
  if (!inst) return;
  clearSelectionInternal(inst);
}

export function dispose(instanceId) {
  const inst = instances.get(instanceId);
  if (!inst) return;
  try { inst.cy.destroy(); } catch {}
  instances.delete(instanceId);
}
