/* Meridian Console - Architecture Park (Cytoscape)
   - Districts are compound parent nodes.
   - Nodes have preset positions.
   - Explode moves districts away from center while preserving relative placement.
*/

const cytoscapeRef = (typeof window !== "undefined" ? window.cytoscape : globalThis.cytoscape);
if (!cytoscapeRef) {
  // If this fires, index.html isn't loading cytoscape before the module.
  console.warn("cytoscape not found on window. Ensure cytoscape.min.js is loaded in index.html.");
}

const instances = new Map();

function normKind(k) {
  const x = (k || "").toUpperCase();
  if (x === "WS" || x === "WSS" || x === "WEBSOCKET") return "WSS";
  if (x === "HTTP" || x === "HTTPS" || x === "GRPC") return "HTTP";
  if (x === "AMQP" || x === "RABBITMQ") return "AMQP";
  if (x === "DB" || x === "DATABASE") return "DB";
  if (x === "DNS") return "DNS";
  return "OTHER";
}

function makeElements(data) {
  const els = [];

  // District parent nodes
  for (const d of (data.districts || [])) {
    els.push({
      data: { id: d.id, label: d.name, kind: "district" },
      classes: "district",
      grabbable: false,
      selectable: false
    });
  }

  for (const n of (data.nodes || [])) {
    const kind = (n.kind || "service").toLowerCase();
    const label = `${n.emoji || "⬚"} ${n.name || n.id}`;
    els.push({
      data: {
        id: n.id,
        label,
        name: n.name || n.id,
        kind,
        district: n.district || "",
        description: n.description || "",
        ports: n.ports || [],
        endpoints: n.endpoints || [],
        responsibilities: n.responsibilities || [],
        baseX: (n.position?.x ?? 0),
        baseY: (n.position?.y ?? 0)
      },
      position: { x: (n.position?.x ?? 0), y: (n.position?.y ?? 0) },
      classes: `n-${kind}`,
      parent: n.district || undefined
    });
  }

  for (const e of (data.edges || [])) {
    const k = normKind(e.kind);
    els.push({
      data: {
        id: e.id,
        source: e.source,
        target: e.target,
        kind: k,
        label: e.label || k
      },
      classes: `e-${k}`
    });
  }

  return els;
}

function createCy(hostEl, elements, options) {
  const cy = cytoscapeRef({
    container: hostEl,
    layout: { name: "preset" },
    elements,
    boxSelectionEnabled: false,
    wheelSensitivity: 0.14,
    userZoomingEnabled: true,
    userPanningEnabled: true,
    minZoom: options?.mode === "embed" ? 0.2 : 0.1,
    maxZoom: 2.0,
    style: [
      {
        selector: "core",
        style: {
          "background-color": "transparent"
        }
      },
      {
        selector: ".district",
        style: {
          "shape": "roundrectangle",
          "background-color": "rgba(255,255,255,0.03)",
          "border-color": "rgba(255,255,255,0.15)",
          "border-width": 1,
          "label": "data(label)",
          "text-valign": "top",
          "text-halign": "center",
          "font-size": 12,
          "color": "rgba(255,255,255,0.55)",
          "text-margin-y": 8,
          "padding": 18
        }
      },
      {
        selector: "node",
        style: {
          "label": "data(label)",
          "font-size": 12,
          "color": "rgba(255,255,255,0.88)",
          "text-wrap": "wrap",
          "text-max-width": 160,
          "text-valign": "center",
          "text-halign": "center",
          "background-color": "rgba(99,102,241,0.20)",
          "border-color": "rgba(99,102,241,0.65)",
          "border-width": 1.5,
          "shape": "roundrectangle",
          "padding": 10,
          "width": "label",
          "height": "label"
        }
      },
      { selector: ".n-db", style: { "background-color": "rgba(168,85,247,0.18)", "border-color": "rgba(168,85,247,0.75)", "shape": "ellipse" } },
      { selector: ".n-agent", style: { "background-color": "rgba(34,197,94,0.16)", "border-color": "rgba(34,197,94,0.75)", "shape": "hexagon" } },
      { selector: ".n-foundation", style: { "background-color": "rgba(14,165,233,0.16)", "border-color": "rgba(14,165,233,0.75)", "shape": "diamond" } },
      { selector: ".n-external", style: { "background-color": "rgba(245,158,11,0.16)", "border-color": "rgba(245,158,11,0.75)", "shape": "roundrectangle" } },
      { selector: ".n-client", style: { "background-color": "rgba(148,163,184,0.16)", "border-color": "rgba(148,163,184,0.75)", "shape": "ellipse" } },

      {
        selector: "edge",
        style: {
          "curve-style": "bezier",
          "width": 2,
          "line-color": "rgba(255,255,255,0.22)",
          "target-arrow-shape": "triangle",
          "target-arrow-color": "rgba(255,255,255,0.22)",
          "label": "data(label)",
          "font-size": 10,
          "text-rotation": "autorotate",
          "text-margin-y": -8,
          "color": "rgba(255,255,255,0.55)",
          "text-background-opacity": 0.0
        }
      },
      { selector: ".e-HTTP", style: { "line-style": "solid" } },
      { selector: ".e-WSS", style: { "line-style": "dashed" } },
      { selector: ".e-AMQP", style: { "line-style": "dotted" } },
      { selector: ".e-DB", style: { "line-style": "solid", "width": 2.5 } },
      { selector: ".e-DNS", style: { "line-style": "dashed", "width": 1.5 } },
      { selector: ".e-OTHER", style: { "line-style": "solid", "width": 1.8, "opacity": 0.8 } },

      { selector: ".dim", style: { "opacity": 0.14 } },
      { selector: ".selected", style: { "border-width": 3, "border-color": "rgba(255,255,255,0.85)" } },
      { selector: ".tour-focus", style: { "opacity": 1.0, "line-color": "rgba(99,102,241,0.75)", "target-arrow-color": "rgba(99,102,241,0.75)" } },
      { selector: "edge.tour-focus", style: { "width": 3 } },
    ]
  });

  // Smoother initial render
  cy.on("render", () => {});
  return cy;
}

function computeCenters(data) {
  const districts = new Map();
  for (const d of (data.districts || [])) {
    districts.set(d.id, { x: d.center?.x ?? 0, y: d.center?.y ?? 0 });
  }

  // global center
  let sx = 0, sy = 0, c = 0;
  for (const v of districts.values()) {
    sx += v.x; sy += v.y; c++;
  }
  const global = c ? { x: sx / c, y: sy / c } : { x: 0, y: 0 };
  return { districts, global };
}

function applyExplode(inst) {
  const { cy, data, explode } = inst;
  const { districts, global } = computeCenters(data);
  const t = Math.max(0, Math.min(1, (explode ?? 0) / 100));
  const factor = 2.2 * t;

  cy.nodes().forEach(n => {
    if (n.isParent()) return;
    const baseX = n.data("baseX") ?? 0;
    const baseY = n.data("baseY") ?? 0;
    const dId = n.data("district");
    const dc = districts.get(dId) || global;
    const dx = (dc.x - global.x) * factor;
    const dy = (dc.y - global.y) * factor;
    n.position({ x: baseX + dx, y: baseY + dy });
  });
}

function clearDim(cy) {
  cy.elements().removeClass("dim");
}

function dimAllBut(cy, focusEls) {
  cy.elements().addClass("dim");
  focusEls.removeClass("dim");
}

function setKindsInternal(inst, kindsArr) {
  const allowed = new Set((kindsArr || []).map(normKind));
  inst.allowedKinds = allowed;

  inst.cy.edges().forEach(e => {
    const k = normKind(e.data("kind"));
    e.style("display", allowed.has(k) ? "element" : "none");
  });

  // Keep nodes visible; dim disconnected ones lightly.
  const visibleEdges = inst.cy.edges().filter(e => e.style("display") !== "none");
  const connected = new Set();
  visibleEdges.forEach(e => {
    connected.add(e.source().id());
    connected.add(e.target().id());
    connected.add(e.id());
  });

  inst.cy.nodes().forEach(n => {
    if (n.isParent()) return;
    if (connected.has(n.id())) n.removeClass("dim");
    else n.addClass("dim");
  });
}

function searchInternal(inst, q) {
  const query = (q || "").trim().toLowerCase();
  inst.query = query;

  if (!query) {
    clearDim(inst.cy);
    // reapply dim for kind filter
    setKindsInternal(inst, Array.from(inst.allowedKinds || ["HTTP","WSS","AMQP","DB","DNS","OTHER"]));
    return;
  }

  const matches = inst.cy.nodes().filter(n => {
    if (n.isParent()) return false;
    const name = (n.data("name") || "").toLowerCase();
    const id = (n.id() || "").toLowerCase();
    return name.includes(query) || id.includes(query);
  });

  if (matches.length === 0) {
    inst.cy.elements().addClass("dim");
    return;
  }

  const focus = matches.union(matches.neighborhood().union(matches.connectedEdges()));
  dimAllBut(inst.cy, focus);
}

function clearSelectionInternal(inst) {
  inst.cy.nodes().removeClass("selected");
  inst.selected = null;
}

function clearTourInternal(inst) {
  inst.tour = null;
  inst.cy.elements().removeClass("tour-focus");
  // restore filtering + search
  setKindsInternal(inst, Array.from(inst.allowedKinds || ["HTTP","WSS","AMQP","DB","DNS","OTHER"]));
  searchInternal(inst, inst.query || "");
}

function applyTour(inst, tourId, stepIndex) {
  const data = inst.data;
  const tour = (data.tours || []).find(t => t.id === tourId);
  if (!tour) return;
  const step = tour.steps?.[stepIndex] || tour.steps?.[0];
  if (!step) return;

  inst.tour = { tourId, stepIndex };

  inst.cy.elements().removeClass("tour-focus");
  const focusNodes = new Set(step.focusNodes || []);
  const focusEdges = new Set(step.focusEdges || []);

  const focusEls = inst.cy.collection();
  inst.cy.nodes().forEach(n => {
    if (!n.isParent() && focusNodes.has(n.id())) focusEls.merge(n);
  });
  inst.cy.edges().forEach(e => {
    if (focusEdges.has(e.id())) focusEls.merge(e);
  });

  inst.cy.elements().addClass("dim");
  focusEls.removeClass("dim");
  focusEls.addClass("tour-focus");

  // Expand focus with immediate neighborhood for context
  const context = focusEls.union(focusEls.neighborhood());
  context.removeClass("dim");

  inst.cy.fit(context, 90);
}

// Public API

export function init(instanceId, hostEl, data, options) {
  if (!hostEl) return;

  // Clear host
  hostEl.innerHTML = "";

  const elements = makeElements(data);
  const cy = createCy(hostEl, elements, options);

  const inst = {
    cy,
    hostEl,
    data,
    explode: 0,
    allowedKinds: new Set(["HTTP","WSS","AMQP","DB","DNS","OTHER"]),
    query: "",
    selected: null,
    tour: null,
    selectable: options?.selectable === true,
    dotnet: options?.dotnet || null
  };

  instances.set(instanceId, inst);

  // Events
  if (inst.selectable) {
    cy.on("tap", "node", async (evt) => {
      const n = evt.target;
      if (!n || n.isParent()) return;
      clearSelectionInternal(inst);
      n.addClass("selected");
      inst.selected = n.id();
      if (inst.dotnet && typeof inst.dotnet.invokeMethodAsync === "function") {
        try { await inst.dotnet.invokeMethodAsync("OnNodeSelected", n.id()); } catch {}
      }
    });
  }

  // Start with explode 0; caller can set
  applyExplode(inst);
  setKindsInternal(inst, Array.from(inst.allowedKinds));
}

export function setExplode(instanceId, value) {
  const inst = instances.get(instanceId);
  if (!inst) return;
  inst.explode = Number(value || 0);
  applyExplode(inst);
  inst.cy.resize();
}

export function setKinds(instanceId, kindsArr) {
  const inst = instances.get(instanceId);
  if (!inst) return;
  setKindsInternal(inst, kindsArr);
  // Preserve search
  if (inst.query) searchInternal(inst, inst.query);
}

export function search(instanceId, q) {
  const inst = instances.get(instanceId);
  if (!inst) return;
  searchInternal(inst, q);
}

export function fit(instanceId) {
  const inst = instances.get(instanceId);
  if (!inst) return;
  inst.cy.fit(inst.cy.elements(":visible"), 70);
}

export function reset(instanceId) {
  const inst = instances.get(instanceId);
  if (!inst) return;
  clearSelectionInternal(inst);
  clearTourInternal(inst);
  inst.query = "";
  inst.allowedKinds = new Set(["HTTP","WSS","AMQP","DB","DNS","OTHER"]);
  inst.explode = 0;
  applyExplode(inst);
  setKindsInternal(inst, Array.from(inst.allowedKinds));
  clearDim(inst.cy);
  inst.cy.fit(inst.cy.elements(":visible"), 70);
}

export function clearSelection(instanceId) {
  const inst = instances.get(instanceId);
  if (!inst) return;
  clearSelectionInternal(inst);
}

export function setTour(instanceId, tourId, stepIndex) {
  const inst = instances.get(instanceId);
  if (!inst) return;
  applyTour(inst, tourId, Number(stepIndex || 0));
}

export function clearTour(instanceId) {
  const inst = instances.get(instanceId);
  if (!inst) return;
  clearTourInternal(inst);
}

export function dispose(instanceId) {
  const inst = instances.get(instanceId);
  if (!inst) return;
  try { inst.cy.destroy(); } catch {}
  instances.delete(instanceId);
}
