namespace Dhadgar.Scope;

public static class Hello
{
    public static string Message => "Hello from Dhadgar.Scope";
}
